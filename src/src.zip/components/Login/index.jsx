import { Loging } from "";

export default Loging;