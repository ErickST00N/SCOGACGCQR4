import React, { Component } from 'react';
import "./menu.css";

class Menu extends Component  {
   desplegarmenu = () => {
        
   }    
    render(){
            return <div className='main-menu'>
                {/* <button className="btn-menu" onClick={desplegarmenu}>|||</button> */}
                <div className="foto-menu">
                    
                </div><button type="button" className="btn-close" data-bs-dismiss="alert" aria-label="Close" />
                <div className="main-menu-list"><ul>
                    <li>Home</li>
                    <li>Actualizar datos</li>
                    <li>Cambiar contraseña</li>
                    <li>Mi credencial</li>
                    <li>Acceso sin credencial</li>
                    <li>Cerrar Sesión</li>
                    <li>Tutorial</li>
                    <li>Acerda de</li>
                </ul></div>
            </div>
        
        
    }
}

export default Menu;