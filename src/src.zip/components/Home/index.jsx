import React from 'react';

const Home = ({correoUser}) => {
    return (
        <div>

        </div>
    )
}

export default Home;